#
#  Validate a Virtual machine on Azure
#
#  Author: Jeff Parker
#  Copyright (c) 2019 Fujitsu
#

# Import machine definitions done as command line
#my_vms = yaml(content: inspec.profile.file('<file name>')).params

# parse the test attribute passed in the command line --input-file option
vm = attribute('vm', description: 'the contents')

# This should have content as follows

#vm:   
#   vmname: uksdvnex001
# 	azresource_group: pol-hzn-dv-plt-uks-nex-rg
# 	vmtype: Microsoft.Compute/virtualMachines
# 	vmloc: uksouth
# 	vmos: linux
# 	vmnic: uksdvnex001-nic-0
# 	vmsize: 'Standard_B2ms'
# 	vnet: dv-dev-uks-vnet
# 	vnet_rg: pol-hzn-dv-plt-uks-mgt-rg
# 	subnet: dv-plt-nex-uks-sub
#
# where: 
# vmname - name of virtual machine
# azresource_group - where the virtual machine resides
# vmtype - type of virtual machine
# vmloc - region where vmresides
# vmos - operating system 
# vmsize = 'Standard_B2s'
# vm:

#
# Validate content
#

#	Blat out what we are testing
print "\n"
print "Validate: "
print vm['desc']
print "\nValidate: resource-group:'"	
print vm['azresource_group']
print "' virtual machine:'"
print vm['vmname']
print "'\n"


# run some tests 	
control 'check-resource-group-properties' do
	title 'Ensure Resource Group properties are correct'
	describe azure_resource_group(name: vm['azresource_group']) do
		its('location') { should eq vm['vmloc'] }
		#it { should have_tags }
		#its('tag_count') { should be 2 }
	end
end	

control 'check-if-resource-group-exists' do
	impact 1.0
	title 'Ensure Resource Group Exists'
	describe azurerm_resource_groups.where(name: vm['azresource_group']) do
		it { should exist }
	end
end

control 'check-if-virtual-machine-exists' do
	title 'Ensure Virtual machine is there'
	describe azurerm_virtual_machines.where(name: vm['vmname']) do
		it { should exist }
	end
end

control 'check-if-azure-virtual-machine-exists' do
	title 'Ensure Virtual Machine is configured' 
	impact 1.0
	describe azure_virtual_machine(group_name: vm['azresource_group'], name: vm['vmname']) do
		its('type')                       	{ should eq vm['vmtype'] }
		its('location')                   	{ should eq vm['vmloc']}
		its('name')						  	{ should eq vm['vmname']}
		its('os_type') 				      	{ should cmp vm['vmos']}
		its('computer_name') 			  	{ should cmp vm['vmname'] }
		its('vm_size')                    	{ should cmp vm['vmsize'] }
		its('connected_nics')				{ should include vm['vmnic'] }
		it { should have_managed_osdisk }
#			it {should have_monitoring_agent_installed}
#			its('os_disk_name') 			  	{ should cmp osdiskname}
#			its('disk_size_gb') 				{ should cmp osdisksize}
#			its('data_disk_count') 				{ should cmp datadisks}
#			its('nic_count') 					{ should eq 1}
#			it {should have_boot_diagnostics}
		it {should have_tags}
#			its ('tag_count') 					{should cmp nooftags}
#			its ('Name_tag') 					{should eq tag1}
#			its ('Name2_tag')					{should eq tag2}
	end
end

# control 'check-azure--vm-network-security-group' do
	# title 'Ensure Network Seurity Group is configured'
	# describe azurerm_network_security_group(resource_group: vm['azresource_group'], name: vm['nsg']) do
		# it                            { should exist }
		# its('type')                   { should eq 'Microsoft.Network/networkSecurityGroups' }
		# its('security_rules')         { should_not be_empty }
		# its('default_security_rules') { should_not be_empty }
		# it                            { should_not allow_rdp_from_internet }
		# it                            { should_not allow_ssh_from_internet }
	# end
# end

control 'check-azure-vm-virtual-network' do
	title 'Ensure Virtual Network is configured'
	describe azurerm_virtual_network(resource_group: vm['vnet_rg'], name: vm['vnet']) do
		it               { should exist }
		its('location')  { should eq vm['vmloc'] }
		its('subnets')	 {should include vm['subnet']}
	end
end

control 'check-azure-vm-network interface' do
	title 'Ensure Subnet is configured'
	describe azurerm_subnet(resource_group: vm['vnet_rg'], vnet: vm['vnet'], name: vm['subnet']) do
		it {should exist}
#			its('address_prefix')	{should eq subnetprefix}
#			its('nsg') 				{should eq vm['nsg']}
	end
end