InSpec Azure Test Suite
=======================
InSpec is Chef’s open-source language for describing security and compliance rules. This example shows how to run InSpec tests on Azure Resources using the [Azure Service Pack](https://github.com/inspec/inspec-azure).

## Getting started

See [Wiki](https://pol-hngt-githubent.mycnets.com/parkerj/inspec-azure-polcf/wiki) for details on how to get InSpec configured for Azure testing.

To use the Test Suite download from Github and cd into `inspec-azure-polcf`.
```
git clone https://pol-hngt-githubent.mycnets.com/parkerj/inspec-azure-polcf.git
cd inspec-azure-polcf
inspec vendor --overwrite
```

## Tests Available

Tests are run via the `inspec exec` command against input file via the following command:

```
$ inspec exec . --input-file files/<filename> --reporter=cli  -t azure://
```
Where `<filename>` is defined by test input file name in the table below.

For example the command:

```
$ inspec exec . --input-file files/nexus-dv.yml --reporter=cli  -t azure://
```
will run the Nexus Virtual Machine configuration test in the DEV environment.

Available tests in the table below.

| Environment | System | Description  | Test Input |
|---|---|---|---|
| DEV | Nexus | Azure VM DEV 01 Configuration Test | `nexus/nexus-dv-001.yml` |
| PROD | Nexus | Azure VM PROD 01 Configuration Test | `nexus/nexus-pr-001.yml` |
|DEV | Jira | Azure VM DEV 01 Configuration Test | `jira/jira-dv-001.yml` |
|PROD | Jira | Azure VM PROD} 01 Configuration Test | `jira/jira-pr-001.yml` |
|DEV | Github | Azure VM DEV 01 Configuration Test | `github/github-dv-001.yml` |
|DEV | Github | Azure VM DEV 03 Configuration Test | `github/github-dv-003.yml` |
|PROD | Github | Azure VM PROD 01 Configuration Test | `github/github-pr-001.yml` |
|PROD | Github | Azure VM PROD 02 Configuration Test | `github/github-pr-002.yml` |
|PROD | Github | Azure VM PROD 03 Configuration Test | `github/github-pr-003.yml` |
|DEV | SNMP | Azure VM DEV 01 Configuration Test | `snmp/snmp-dv-001.yml` |
| DEV | Confluence | Azure VM DEV 01 Configuration Test | `confluence/confluence-dv-001.yml` |
| PROD | Confluence | Azure VM PROD 01 Configuration Test | `confluence/confluence-pr-001.yml` |

Subscriptions for Test need to be set as follows:

|Environment|Subscription ID|
|---|---|
|DEV |ea627c65-fb80-4cf2-b22c-124e9fdc89c7|


## Running tests

Test can be consolidated via the Command shell for each command e.g. 
```
for /r  %i in (files\*dv*) do inspec exec . --input-file $i  --reporter progress -t azure://
```
will run all the DEV subscription tests.


