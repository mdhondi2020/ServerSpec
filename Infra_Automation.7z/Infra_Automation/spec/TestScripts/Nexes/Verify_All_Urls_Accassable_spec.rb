# ---------------------------------------------------------------
# Check Builds for HIH and Branch can use migrated respositories and Proxies are correctly configured, 
#see blue print for proxied URLs and access routes
require 'spec_helper'

	# Verify Url https://pypi.python.org is accessable
	describe host('https://pypi.python.org/') do
		it 'Should be reachable' do
			(should be_reachable)
		end
	end	

	#Verify Url http://archive.ubuntu.com/ubuntu is accessable
	describe host('http://archive.ubuntu.com/ubuntu/') do
		it 'Should be reachable' do
			(should be_reachable)
		end
	end
	
	#Verify Url https://registry-1.docker.io is accessable
	describe host('https://registry-1.docker.io') do
		it 'Should be reachable' do
			(should be_reachable)
		end
	end
	#Verify Url https://rubygems.org is accessable
	describe host('https://rubygems.org') do
		it 'Should be reachable' do
			(should be_reachable)
		end
	end

	#Verify Url https://registry.npmjs.org is accessable
	describe host('https://registry.npmjs.org') do
		it 'Should be reachable' do
			(should be_reachable)
		end
	end	