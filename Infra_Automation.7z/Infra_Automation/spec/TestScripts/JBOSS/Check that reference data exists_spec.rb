# ---------------------------------------------------------------
# Check that reference data exists
require 'spec_helper'

describe 'Reference data resources' do


reference_data = [

'/opt/BFCS/cws-properties',
'/opt/BFCS/log',
'/opt/BFCS/cachedata/csvfiles',
'/opt/BFCS/cachedata/live',
'/opt/BFCS/PODG/scripts',
'/opt/BFCS/PODG/xsds',
'/opt/BFCS/PODG/daily/crd/current',
'/opt/BFCS/PODG/daily/crd/error',
'/opt/BFCS/PODG/daily/crd/processed',
'/opt/BFCS/PODG/daily/brd/current',
'/opt/BFCS/PODG/daily/brd/error',
'/opt/BFCS/PODG/daily/brd/processed',
'/opt/BFCS/PODG/daily/ioh/current',
'/opt/BFCS/PODG/daily/ioh/error',
'/opt/BFCS/PODG/daily/ioh/processed',
'/opt/BFCS/PODG/eventbased/branchfull/current',
'/opt/BFCS/PODG/ eventbased /branchfull/error',
'/opt/BFCS/PODG/ eventbased /branchfull/processed'

]

describe 'Reference data resources' do
	reference_data.each do|file|
		describe file do
		    it { should be_file}
			it { should be_owned_by 'cwsuser' }
			it { should be_grouped_into 'cwsuser' }
		end
	end
end


end