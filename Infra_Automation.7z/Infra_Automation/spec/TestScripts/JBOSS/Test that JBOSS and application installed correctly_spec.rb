require 'spec_helper'
# ----------------------------------------------------------
# Test that JBOSS and application installed correctly

describe 'JBOSS and CWS installed' do 
		describe package('unzip') do
			it { should be_installed }
		end

		describe user('cwsuser') do
			it { should exist }
		end

		describe group('cwsuser') do
			it { should exist }
		end

		describe user('cwsuser') do
			it { should belong_to_group 'cwsuser' }
		end

		describe file('/opt/BFCS') do
			it { should be_directory }
			it { should be_owned_by 'cwsuser' }
			it { should be_grouped_into 'cwsuser' }
		end

		describe file('/opt/BFCS/jboss-eap-5.1/jboss-as') do
			it { should be_directory }
			it { should be_owned_by 'cwsuser' }
			it { should be_grouped_into 'cwsuser' }
		end

		describe file('/opt/BFCS/jboss-eap-5.1/jboss-as/lib/endorsed') do
			it { should be_directory }
			it { should be_owned_by 'cwsuser' }
			it { should be_grouped_into 'cwsuser' }
		end

		describe file('/opt/BFCS/jboss-eap-5.1/jboss-as/server/web/lib/spring.jar') do
			it { should be_file }
			it { should be_owned_by 'cwsuser' }
			it { should be_grouped_into 'cwsuser' }
		end

		describe file('/opt/BFCS/jboss-eap-5.1/jboss-as/server/default/lib/spring.jar') do
			it { should be_file }
			it { should be_owned_by 'cwsuser' }
			it { should be_grouped_into 'cwsuser' }
		end

end
