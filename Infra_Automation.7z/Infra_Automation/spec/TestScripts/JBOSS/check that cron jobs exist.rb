
# check that cron jobs exist

#
# test cron expression for Data import from PODG
#

PODG_jobs = [

# At early morning 5:01, this cron executes file_transfer.sh to pull CRD files from PODG. It takes one argument CRD
'01  5   *  *  *   /opt/BFCS/PODG/scripts/file_transfer.sh CRD > /tmp/ft.sh 2>&1',

# At early morning 5:02, this cron executes file_transfer.sh to pull BRD files from PODG. It takes one argument BRD
	'02  5   *  *  *   /opt/BFCS/PODG/scripts/file_transfer.sh BRD > /tmp/ft.sh 2>&1', 

	# At every 10 minutes, this cron executes file_transfer.sh to pull BFE files from PODG. It takes one argument BFE
	*/10   *  *  *  *   /opt/BFCS/PODG/scripts/file_transfer.sh 'BFE > /tmp/ft.sh 2>&1',

	# At 11:02pm every day, this cron executes file_transfer.sh to pull IOH files from PODG. It takes one argument IOH
	'02  23   *  *   *   /opt/BFCS/PODG/scripts/file_transfer.sh IOH > /tmp/ft.sh 2>&1',

	# At 1:15am every day, this cron executes file_transfer.sh to push BLCS files from CWS to PODG. It takes one argument BLCS
	'15  1  *  *   *   /opt/BFCS/PODG/scripts/file_transfer.sh  BLCS > /tmp/ft.sh 2>&1',
]

describe 'cron definitions for Data import from PODG' do
	PODG_jobs.each do|job|
		describe file do
			it { should have_entry job }
		end
	end
end