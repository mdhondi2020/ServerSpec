# ---------------------------------------------------------------
# Check BMX Monitoring extended to include CWS Applications
require 'spec_helper'

describe 'BMX Monitoring extended' do
  # A new monitor file has been created. This can be found under /opt/bmx/conf/extensions called cws_monitor.xml ???. 
  describe file('/etc/passwd') do
	it { should exist }
	end

# Or
	describe file('/etc/passwd') do
	it { should be_file }
	end
end  