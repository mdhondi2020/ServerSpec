# ---------------------------------------------------------------
# Check installation and functioning of EPAAS system spec
require 'spec_helper'

describe 'EPAAS system installed' do
  # Check package is installed 
  describe package('requests') do
    it 'Should be installed with Version 2.18.1' do
      (should be_installed.by('pip').with_version('2.18.1')) 
    end
  end  
  # Check that EPAAS process is running
	describe process("memcached") do
    it 'Should be EPAAS process is running' do 
      (should be_running)
    end
  end
end   