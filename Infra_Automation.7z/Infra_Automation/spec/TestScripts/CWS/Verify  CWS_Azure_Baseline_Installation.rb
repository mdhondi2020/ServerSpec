# ---------------------------------------------------------------
# Check installation and functioning of EPAAS system spec
require 'spec_helper'

describe 'EPAAS system installed' do
  # package is installed 
  describe package('requests') do
    it { should be_installed.by('pip').with_version('2.18.1') }
  end
end  