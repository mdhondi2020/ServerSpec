# ---------------------------------------------------------------
# Check that CWS application is listening
require 'spec_helper'

describe 'CWS Port resource type' do
  # port  
  describe port(8080) do
    # be_listening  
    it { should be_listening }
 
    # be_listening_with  
    it { should be_listening.with('tcp') }
  end
end

