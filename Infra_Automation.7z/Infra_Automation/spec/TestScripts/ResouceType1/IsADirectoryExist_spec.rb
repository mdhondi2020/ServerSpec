require 'spec_helper'
describe file('C:\Program Files\Notepad++') do
  it { should be_directory }
end
