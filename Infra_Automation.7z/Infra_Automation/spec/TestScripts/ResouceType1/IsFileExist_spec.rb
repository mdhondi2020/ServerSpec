require 'spec_helper'
describe file ('c:/tools/test.txt') do 
	it { should be_file }
end