# ---------------------------------------------------------------
# Check Builds for Github some of the Urls are accassable 
require 'spec_helper'

	# Verify Url https:Fujitsu.domains@uk.fujitsu.com  is accessable
	describe host('https://fujitsu.domains@uk.fujitsu.com /') do
		it 'Should be reachable' do
			(should be_reachable)
		end
	end	

	#Verify Url https://pol-hngt-githubent.mycnets.com is accessable // need to check with Michael
	#  Verify Url https://github.pohzn.com is accessable // need to ceck with Michael
	describe host('https://github.pohzn.com') do
		it 'Should be reachable' do
			(should be_reachable)
		end
	end
	
	#Verify the GitHub Server is running only on port HTTPS 
	# Verify Url GitHub Server is running on port <xxx.x.x.x.> and with https protocol 
	describe port(80) do
	it { should be_listening.on('127.0.0.1').with('https') }
	end
	
