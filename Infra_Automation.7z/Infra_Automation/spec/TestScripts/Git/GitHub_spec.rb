require 'spec_helper'

#Two Storage Volumes Exist
describe file('/data/user') do
    it { should be_directory }
end

describe file('/') do
  it { should be_directory }
end

#Root filesystem Custom Authority Certificates
describe file('/usr/local/share/ca-certificates') do
    it { should be_directory }
end

#Checking Azure Hostnames
describe 'Azure Server Names' do
    #Git Appliance - Development
    describe host('uksdvghb001') do
        it { should be_resolvable }  
    end

    #Linux Backup Snapshot server
    describe host('uksdvghb003') do
        it { should be_resolvable }  
    end
end

#Checking Ports are Listening
describe 'Port Checking' do
    #Git over SSH
    describe port('22') do
        it { should be_listening }
    end
    #SMTP with Encryption
    describe port('25') do
        it { should be_listening }
    end
    #HTTP Web App Access
    describe port('80') do
        it { should be_listening }
    end
    #SSH Instance Shell Access
    describe port('122') do
        it { should be_listening }
    end
    #SNMP Network Monitoring
    describe port('161') do
        it { should be_listening.with('udp') }
    end
    #Git Access over HTTPS
    describe port('443') do
        it { should be_listening }
    end
    #VPN Network Tunnel
    describe port('1194') do
        it { should be_listening.with('udp') }
    end
    #HTTP Management Console
    describe port('8080') do
        it { should be_listening }
    end
    #HTTPS Secure Management Console
    describe port('8443') do
        it { should be_listening }
    end
    #Git Protocol Port
    describe port('9418') do
        it { should be_listening }
    end
end
