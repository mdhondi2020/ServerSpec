require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-3.1 Network Parameters (Host Only)' do

	it 'CIS-RHEL7-v2.2.0-3.1.1 Ensure IP forwarding is disabled' do
	  expect(command('/sbin/sysctl net.ipv4.ip_forward').stdout).to match(/^net.ipv4.ip_forward = 0/)
	end
   
	it 'CIS-RHEL7-v2.2.0-3.1.2 Ensure packet redirect sending is disabled' do
	  expect(command('/sbin/sysctl net.ipv4.conf.all.send_redirects').stdout).to match(/^net.ipv4.conf.all.send_redirects = 0/)
	  expect(command('/sbin/sysctl net.ipv4.conf.default.send_redirects').stdout).to match(/^net.ipv4.conf.default.send_redirects = 0/)
	end

end