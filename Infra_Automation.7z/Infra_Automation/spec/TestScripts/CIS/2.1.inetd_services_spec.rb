require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-2.1 inetd Services' do

	it 'CIS-RHEL7-v2.2.0-2.1.1 Ensure chargen services are not enabled' do
	  expect(service('chargen-dgram')).to_not be_running
 	  expect(service('chargen-dgram')).to_not be_enabled
 	  expect(service('chargen-stream')).to_not be_running
 	  expect(service('chargen-stream')).to_not be_enabled
 	end

	it 'CIS-RHEL7-v2.2.0-2.1.2 Ensure daytime services are not enabled' do
          expect(service('daytime-dgram')).to_not be_running
          expect(service('daytime-dgram')).to_not be_enabled
          expect(service('daytime-stream')).to_not be_running
          expect(service('daytime-stream')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.1.3 Ensure discard services are not enabled' do
          expect(service('discard-dgram')).to_not be_running
          expect(service('discard-dgram')).to_not be_enabled
          expect(service('discard-stream')).to_not be_running
          expect(service('discard-stream')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.1.4 Ensure echo services are not enabled' do
          expect(service('echo-dgram')).to_not be_running
          expect(service('echo-dgram')).to_not be_enabled
          expect(service('echo-stream')).to_not be_running
          expect(service('echo-stream')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.1.5 Ensure time services are not enabled' do
          expect(service('time-dgram')).to_not be_running
          expect(service('time-dgram')).to_not be_enabled
          expect(service('time-stream')).to_not be_running
          expect(service('time-stream')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.1.6 Ensure tftp server is not enabled' do
		  expect(service('tftp')).to_not be_running
          expect(service('tftp')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.1.11 Ensure xinetd is not enabled' do
          expect(service('xinetd')).to_not be_running
          expect(service('xinetd')).to_not be_enabled
        end

end