require 'spec_helper'


describe 'CIS-RHEL7-v2.2.0-3.2 Network Parameters (Host and Router)' do

	it 'CIS-RHEL7-v2.2.0-3.2.1 Ensure source routed packets are not accepted' do
	  expect(command('/sbin/sysctl net.ipv4.conf.all.accept_source_route').stdout).to match(/^net.ipv4.conf.all.accept_source_route = 0/)
	  expect(command('/sbin/sysctl net.ipv4.conf.default.accept_source_route').stdout).to match(/^net.ipv4.conf.default.accept_source_route = 0/)
	end

	it 'CIS-RHEL7-v2.2.0-3.2.2 Ensure ICMP redirects are not accepted' do
	  expect(command('/sbin/sysctl net.ipv4.conf.all.accept_redirects').stdout).to match(/^net.ipv4.conf.all.accept_redirects = 0/)
          expect(command('/sbin/sysctl net.ipv4.conf.default.accept_redirects').stdout).to match(/^net.ipv4.conf.default.accept_redirects = 0/)
	end

	it 'CIS-RHEL7-v2.2.0-3.2.3 Ensure secure ICMP redirects are not accepted' do
          expect(command('/sbin/sysctl net.ipv4.conf.all.secure_redirects').stdout).to match(/^net.ipv4.conf.all.secure_redirects = 0/)
          expect(command('/sbin/sysctl net.ipv4.conf.default.secure_redirects').stdout).to match(/^net.ipv4.conf.default.secure_redirects = 0/)
	end

	it 'CIS-RHEL7-v2.2.0-3.2.4 Ensure suspicious packets are logged' do
          expect(command('/sbin/sysctl net.ipv4.conf.all.log_martians').stdout).to match(/^net.ipv4.conf.all.log_martians = 1/)
          expect(command('/sbin/sysctl net.ipv4.conf.default.log_martians').stdout).to match(/^net.ipv4.conf.default.log_martians = 1/)
	end

	it 'CIS-RHEL7-v2.2.0-3.2.5 Ensure broadcast ICMP requests are ignored' do
          expect(command('/sbin/sysctl net.ipv4.icmp_echo_ignore_broadcasts').stdout).to match(/^net.ipv4.icmp_echo_ignore_broadcasts = 1/)
	end

	it 'CIS-RHEL7-v2.2.0-3.2.6 Ensure bogus ICMP responses are ignored' do
          expect(command('/sbin/sysctl net.ipv4.icmp_ignore_bogus_error_responses').stdout).to match(/^net.ipv4.icmp_ignore_bogus_error_responses = 1/)
	end

	it 'CIS-RHEL7-v2.2.0-3.2.7 Ensure Reverse Path Filtering is enabled' do
          expect(command('/sbin/sysctl net.ipv4.conf.all.rp_filter').stdout).to match(/^net.ipv4.conf.all.rp_filter = 1/)
	end

	it 'CIS-RHEL7-v2.2.0-3.2.8 Ensure TCP SYN Cookies is enabled' do
          expect(command('/sbin/sysctl net.ipv4.tcp_syncookies').stdout).to match(/^net.ipv4.tcp_syncookies = 1/)
	end

end

