require 'spec_helper'


describe 'CIS-RHEL7-v2.2.0-1.6 Mandatory Access Control' do

	it 'CIS-RHEL7-v2.2.0-1.6.1.1 Ensure SELinux is not disabled in bootloader configuration' do
	  expect(command('grep "^\s*kernel" /boot/grub/grub.conf').stdout).to_not contain ('selinux=0') 
	  expect(command('grep "^\s*kernel" /boot/grub/grub.conf').stdout).to_not contain ('enforcing=0') 
	end

	it 'CIS-RHEL7-v2.2.0-1.6.1.2 Ensure the SELinux state is enforcing' do
	  expect(command('grep SELINUX=enforcing /etc/selinux/config').stdout).to match (/SELINUX=enforcing/)
	  expect(command('/usr/sbin/sestatus | grep ^Current').stdout).to contain ('enforcing')
	end

	it 'CIS-RHEL7-v2.2.0-1.6.1.3 Ensure SELinux policy is configured' do
	  expect(command('grep SELINUXTYPE=targeted /etc/selinux/config').stdout).to match (/SELINUXTYPE=targeted/)
	  expect(command('/usr/sbin/sestatus | grep "^Policy from config file"').stdout).to contain ('targeted')
	end

	it 'CIS-RHEL7-v2.2.0-1.6.1.4 Ensure SETroubleshoot is not installed' do
	  expect(package('setroubleshoot')).to_not be_installed
	end

	it 'CIS-RHEL7-v2.2.0-1.6.1.5 Ensure the MCS Translation Service (mcstrans) is not installed' do
	  expect(package('mcstrans')).to_not be_installed
	end

	it 'CIS-RHEL7-v2.2.0-1.6.1.5 Ensure no unconfined daemons exist' do
	  expect(command('ps -eZ | egrep "initrc" | egrep -vw "tr|ps|egrep|bash|awk" | tr \':\' \' \' | awk \'{ print $NF }\'').stdout).to match (//)
	end

	it 'CIS-RHEL7-v2.2.0-1.6.2 Ensure SELinux is installed' do
	  expect(package('libselinux')).to be_installed
	end
end