require 'spec_helper'


describe 'CIS-RHEL7-v2.2.0-1.7 Warning Banners' do

	it 'CIS-RHEL7-v2.2.0-1.7.1.1 Ensure message of the day is configured properly' do
	  expect(command('egrep \'(\\v|\\r|\\m|\\s)\' /etc/motd').stdout).to match (//)
	end

	it 'CIS-RHEL7-v2.2.0-1.7.1.2 Ensure local login warning banner is configured properly' do
	  expect(command('egrep \'(\\v|\\r|\\m|\\s)\' /etc/issue').stdout).to match (//)
	end

	it 'CIS-RHEL7-v2.2.0-1.7.1.3 Ensure remote login warning banner is configured properly' do
	  expect(command('egrep \'(\\v|\\r|\\m|\\s)\' /etc/issue.net').stdout).to match (//)
	end

	it 'CIS-RHEL7-v2.2.0-1.7.1.4 Ensure permissions on /etc/motd are configured' do
	  expect(file('/etc/motd')).to be_mode (644)
	  expect(command('stat /etc/motd | grep "Access: (" | awk  {\' print $5 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/motd | grep "Access: (" | awk  {\' print $6 \'}').stdout).to contain ('root')
          expect(command('stat /etc/motd | grep "Access: (" | awk  {\' print $9 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/motd | grep "Access: (" | awk  {\' print $10 \'}').stdout).to contain ('root')
	end

	it 'CIS-RHEL7-v2.2.0-1.7.1.5 Ensure permissions on /etc/issue are configured' do
	  expect(file('/etc/issue')).to be_mode (644)
          expect(command('stat /etc/issue grep "Access: (" | awk  {\' print $5 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/issue | grep "Access: (" | awk  {\' print $6 \'}').stdout).to contain ('root')
          expect(command('stat /etc/issue | grep "Access: (" | awk  {\' print $9 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/issue | grep "Access: (" | awk  {\' print $10 \'}').stdout).to contain ('root')
	end

	it 'CIS-RHEL7-v2.2.0-1.7.1.6 Ensure permissions on /etc/issue.net are configured' do
          expect(file('/etc/issue.net')).to be_mode (644)
          expect(command('stat /etc/issue.net grep "Access: (" | awk  {\' print $5 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/issue.net | grep "Access: (" | awk  {\' print $6 \'}').stdout).to contain ('root')
          expect(command('stat /etc/issue.net | grep "Access: (" | awk  {\' print $9 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/issue.net | grep "Access: (" | awk  {\' print $10 \'}').stdout).to contain ('root')
        end

	it 'CIS-RHEL7-v2.2.0-1.7.2 Ensure GDM login banner is configured' do
	  pending("How to determine whether GDM is installed or not")
	  raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-1.8 Ensure updates, patches, and additional security software are installed' do
	  pending("Not scored. What does this do in section 1.7 Warning Banners anyway :)")
	  raise "This is pending"
	end
end