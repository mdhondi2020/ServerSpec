require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-1.3 Filesystem Integrity Checking' do

	it 'CIS-RHEL7-v2.2.0-1.3.1 Ensure AIDE is installed' do
          expect(package('aide')).to be_installed
	end

	it 'CIS-RHEL7-v2.2.0-1.3.2 Ensure filesystem integrity is regularly checked' do
          expect(cron).to have_entry('0 5 * * * /usr/sbin/aide --check')
 	end

end