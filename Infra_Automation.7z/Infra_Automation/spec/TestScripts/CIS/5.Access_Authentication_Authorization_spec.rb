require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-5 Access, Authentication and Authorization' do


	it 'CIS-RHEL7-v2.2.0-5.1.1 Ensure cron daemon is enabled' do
	  expect(service('crond')).to be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-5.1.2 Ensure permissions on /etc/crontab are configured' do
	  expect(file('/etc/crontab')).to be_mode(600)
	  expect(file('/etc/crontab')).to be_owned_by('root')
	  expect(file('/etc/crontab')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.1.3 Ensure permissions on /etc/cron.hourly are configured' do
	  expect(file('/etc/cron.hourly')).to be_mode(700)
          expect(file('/etc/cron.hourly')).to be_owned_by('root')
          expect(file('/etc/cron.hourly')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.1.4 Ensure permissions on /etc/cron.daily are configured' do
          expect(file('/etc/cron.daily')).to be_mode(700)
          expect(file('/etc/cron.daily')).to be_owned_by('root')
          expect(file('/etc/cron.daily')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.1.5 Ensure permissions on /etc/cron.weekly are configured' do
	  expect(file('/etc/cron.weekly')).to be_mode(700)
	  expect(file('/etc/cron.weekly')).to be_owned_by('root')
          expect(file('/etc/cron.weekly')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.1.6 Ensure permissions on /etc/cron.monthly are configured' do
	  expect(file('/etc/cron.monthly')).to be_mode(700)
	  expect(file('/etc/cron.monthly')).to be_owned_by('root')
          expect(file('/etc/cron.monthly')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.1.7 Ensure permissions on /etc/cron.d are configured' do
	  expect(file('/etc/cron.d')).to be_mode(700)
	  expect(file('/etc/cron.d')).to be_owned_by('root')
          expect(file('/etc/cron.d')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.1.8 Ensure at/cron is restricted to authorized users' do
	  expect(file('/etc/cron.deny')).to be_mode(600)
	  expect(file('/etc/cron.deny')).to be_owned_by('root')
	  expect(file('/etc/cron.deny')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.2.1 Ensure permissions on /etc/ssh/sshd_config are configured' do
	  expect(file('/etc/ssh/sshd_config')).to be_mode(600)
          expect(file('/etc/ssh/sshd_config')).to be_owned_by('root')
          expect(file('/etc/ssh/sshd_config')).to be_grouped_into('root')
	end

	it 'CIS-RHEL7-v2.2.0-5.2.2 Ensure SSH Protocol is set to 2' do
	  expect(command('grep "^Protocol" /etc/ssh/sshd_config').stdout).to match(/^Protocol\s+2/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.3 Ensure SSH LogLevel is set to INFO' do
	  expect(command('grep "^LogLevel" /etc/ssh/sshd_config').stdout).to match(/^LogLevel\s+INFO/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.4 Ensure SSH X11 forwarding is disabled' do
	  expect(command('grep "^X11Forwarding" /etc/ssh/sshd_config').stdout).to match(/^X11Forwarding\s+no/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.5 Ensure SSH MaxAuthTries is set to 4 or less' do
	  expect(command('grep "^MaxAuthTries" /etc/ssh/sshd_config').stdout).to match(/^MaxAuthTries\s+[1-4]/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.6 Ensure SSH IgnoreRhosts is enabled' do
	  expect(command('grep "^IgnoreRhosts" /etc/ssh/sshd_config').stdout).to match(/^IgnoreRhosts\s+yes/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.7 Ensure SSH HostbasedAuthentication is disabled' do
	  expect(command('grep "^HostbasedAuthentication" /etc/ssh/sshd_config').stdout).to match(/^HostbasedAuthentication\s+no/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.8 Ensure SSH root login is disabled' do
	  expect(command('grep "^PermitRootLogin" /etc/ssh/sshd_config').stdout).to match(/^PermitRootLogin\s+no/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.9 Ensure SSH PermitEmptyPasswords is disabled' do
	  expect(command('grep "^PermitEmptyPasswords" /etc/ssh/sshd_config').stdout).to match(/^PermitEmptyPasswords\s+no/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.10 Ensure SSH PermitUserEnvironment is disabled' do
	  expect(command('grep PermitUserEnvironment /etc/ssh/sshd_config').stdout).to match(/^PermitUserEnvironment\s+no/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.11 Ensure only approved ciphers are used' do
	  expect(command('grep "Ciphers" /etc/ssh/sshd_config').stdout).to match(/^Ciphers\s+aes256-ctr,aes192-ctr,aes128-ctr,aes256-gcm@openssh.com,aes128-gcm@openssh.com,chacha20-poly1305@openssh.com/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.12 Ensure only approved MAC algorithms are used' do
	  expect(command('grep "MACs" /etc/ssh/sshd_config').stdout).to match(/^MACs\s+hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,umac-128-etm@openssh.com,hmac-sha2-512,hmac-sha2-256,umac-128@openssh.com,curve25519-sha256@libssh.org,diffie-hellman-group-exchange-sha256/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.13 Ensure SSH Idle Timeout Interval is configured' do
	  expect(command('grep "^ClientAliveInterval" /etc/ssh/sshd_config').stdout).to match(/^ClientAliveInterval\s+\b(0*(?:[1-9][0-9]?|300))\b/)
	  expect(command('grep "^ClientAliveCountMax" /etc/ssh/sshd_config').stdout).to match(/^ClientAliveCountMax\s+[0-3]/)
	end

	it 'CIS-RHEL7-v2.2.0-5.2.14 Ensure SSH LoginGraceTime is set to one minute or less' do
	  expect(command('grep "^LoginGraceTime" /etc/ssh/sshd_config').stdout).to match(/^LoginGraceTime\s+\b(0*(?:[1-9][0-9]?|60))\b/)
	end
	
	it 'CIS-RHEL7-v2.2.0-5.2.15 Ensure SSH warning banner ios configured' do
	  expect(command('grep "^Banner" /etc/ssh/sshd_config').stdout).to match(/^Banner \/etc\/issue.net/)
	end
end