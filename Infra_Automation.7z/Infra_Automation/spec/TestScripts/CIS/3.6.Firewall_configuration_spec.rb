require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-3.6 Firewall Configuration' do

	it 'CIS-RHEL7-v2.2.0-3.6.1 Ensure iptables is installed' do
	  expect(package('iptables')).to be_installed
	end

	it 'CIS-RHEL7-v2.2.0-3.6.2 Ensure default deny firewall policy' do
	  expect(command('iptables -L | grep "^Chain INPUT"').stdout).to match(/Chain INPUT \(policy DROP\)/)
	  expect(command('iptables -L | grep "^Chain FORWARD"').stdout).to match(/Chain FORWARD \(policy DROP\)/)
	  expect(command('iptables -L | grep "^Chain OUTPUT"').stdout).to match(/Chain OUTPUT \(policy DROP\)/)
	end

        it 'CIS-RHEL7-v2.2.0-3.6.3 Ensure loopback traffic is configured' do
          pending("This is too specific and will differ from organization to organization")
          raise "This is pending"
        end

        it 'CIS-RHEL7-v2.2.0-3.6.4 Ensure outbound and established connections are configured' do
          pending("This is too specific and will differ from organization to organization")
          raise "This is pending"
        end

        it 'CIS-RHEL7-v2.2.0-3.6.5 Ensure firewall rules exist for all open ports' do
          pending("Too complex, I don't know how to implement it")
          raise "This is pending"
        end

	it 'CIS-RHEL7-v2.2.0-3.7 Ensure wireless interfaces are disabled' do
	  expect(command('/sbin/ip link show up').stdout).to_not match(/: wl.*UP/)
 	end

end