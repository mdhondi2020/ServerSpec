require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-1.5 Additional Process Hardening' do

	it 'CIS-RHEL7-v2.2.0-1.5.1 Ensure core dumps are restricted' do
	  expect(file('/etc/security/limits.conf')).to match(/\*\s+hard\s+core\s+0/)
	  expect(command('/sbin/sysctl fs.suid_dumpable').stdout).to match(/^fs\.suid_dumpable = 0/)
	end

	it 'CIS-RHEL7-v2.2.0-1.5.2 Ensure XD/NX support is enabled' do
	  pending("Not scored")
	  raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-1.5.3 Ensure address space layout randomization (ASLR) is enabled' do
	  expect(command('/sbin/sysctl kernel.randomize_va_space').stdout).to match(/^kernel\.randomize_va_space = 2/)
	end

	it 'CIS-RHEL7-v2.2.0-1.5.4 Ensure prelink is disabled' do
	  expect(package('prelink')).to_not be_installed
	end

end