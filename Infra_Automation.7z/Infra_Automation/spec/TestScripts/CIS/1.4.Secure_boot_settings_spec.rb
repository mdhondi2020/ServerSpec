require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-1.4 Secure Boot Settings' do

	it 'CIS-RHEL7-v2.2.0-1.4.1 Ensure permissions on bootloader config are configured' do
	  expect(command('stat /boot/grub/grub.conf | grep "Access: (" | awk  {\' print $5 \'}').stdout).to contain ('0/')
	  expect(command('stat /boot/grub/grub.conf | grep "Access: (" | awk  {\' print $6 \'}').stdout).to contain ('root')
	  expect(command('stat /boot/grub/grub.conf | grep "Access: (" | awk  {\' print $9 \'}').stdout).to contain ('0/')
	  expect(command('stat /boot/grub/grub.conf | grep "Access: (" | awk  {\' print $10 \'}').stdout).to contain ('root')
	end

	it 'CIS-RHEL7-v2.2.0-1.4.2 Ensure bootloader password is set' do
	  expect(command('grep "^password" /boot/grub/grub.conf').stdout).to contain ('password')
	end

	it 'CIS-RHEL7-v2.2.0-1.4.3 Ensure authentication required for single user mode' do
	  expect(command('grep ^SINGLE /etc/sysconfig/init').stdout).to match (/SINGLE=\/sbin\/sulogin/)
	end

	it 'CIS-RHEL7-v2.2.0-1.4.4 Ensure interactive boot is not enabled' do
	  expect(command('grep "^PROMPT=" /etc/sysconfig/init').stdout).to match (/PROMPT=no/)
	end
	
end