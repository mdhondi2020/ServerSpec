require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-2.2 Special Purpose Services' do

	it 'CIS-RHEL7-v2.2.0-2.2.1.1 Ensure time synchronization is in use' do
	  expect(package('ntp')).to be_installed 
	  expect(package('chrony')).to be_installed 
	end

	it 'CIS-RHEL7-v2.2.0-2.2.1.2 Ensure ntp is configured' do
	  expect(command('grep "^restrict" /etc/ntp.conf').stdout).to contain(/default kod nomodify notrap nopeer noquery/)
	  expect(command('grep "^OPTIONS" /etc/sysconfig/ntpd').stdout).to contain('OPTIONS="-u ntp:ntp')
	end
	
	it 'CIS-RHEL7-v2.2.0-2.2.1.2 Ensure ntp server is configured' do
	  expect(command('grep "^(server|pool)" /etc/ntp.conf').stdout).to contain(/<<what the heck is the NTP address>>/)
	  pending("Get the NTP server name")
	  raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-2.2.1.3 Ensure chrony is configured' do
	  expect(command('grep "^server" /etc/chrony.conf').stdout).to contain('server')
	  expect(command('grep ^OPTIONS /etc/sysconfig/chronyd').stdout).to contain('OPTIONS="-u chrony')
	end

	it 'CIS-RHEL7-v2.2.0-2.2.2 Ensure X Window System is not installed' do
	  expect(package('xorg-x11*')).to_not be_installed
	end

	it 'CIS-RHEL7-v2.2.0-2.2.3 Ensure Avahi Server is not enabled' do
	  expect(service('avahi-daemon')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.4 Ensure CUPS is not enabled' do
	  expect(service('cups')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.5 Ensure DHCP Server is not enabled' do
	  expect(service('dhcpd')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.6 Ensure LDAP server is not enabled' do
	  expect(service('slapd')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.7 Ensure NFS and RPC are not enabled' do
	  expect(service('nfs')).to_not be_enabled
	  expect(service('rpcbind')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.8 Ensure DNS Server is not enabled' do
	  expect(service('named')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.9 Ensure FTP Server is not enabled' do
	  expect(service('vsftpd')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.10 Ensure HTTP server is not enabled' do
	  expect(service('httpd')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.11 Ensure IMAP and POP3 server is not enabled' do
	  expect(service('dovecot')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.12 Ensure Samba is not enabled' do
	  expect(service('smb')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.13 Ensure HTTP Proxy Server is not enabled' do
	  expect(service('squid')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.14 Ensure SNMP Server is not enabled' do
	  expect(service('snmpd')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.15 Ensure mail transfer agent is configured for local-only mode' do
	  expect(command('netstat -an | grep LIST | grep ":25[[:space:]]"').stdout).to contain('127.0.0.1:25') 
	end

	it 'CIS-RHEL7-v2.2.0-2.2.16 Ensure NIS Server is not enabled' do
	  expect(service('ypserv')).to_not be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-2.2.17 Ensure rsh server is not enabled' do
          expect(service('rexec')).to_not be_running
          expect(service('rexec')).to_not be_enabled
          expect(service('rlogin')).to_not be_running
          expect(service('rlogin')).to_not be_enabled
	      expect(service('rsh')).to_not be_running
          expect(service('rsh')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.2.18 Ensure talk server is not enabled' do
          expect(service('talk')).to_not be_running
          expect(service('talk')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.2.19 Ensure telnet server is not enabled' do
          expect(service('telnet')).to_not be_running
          expect(service('telnet')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.2.20 Ensure tftp server is not enabled' do
          expect(service('tftp')).to_not be_running
          expect(service('tftp')).to_not be_enabled
        end

	it 'CIS-RHEL7-v2.2.0-2.2.21 Ensure rsync service is not enabled' do
	  expect(service('rsync')).to_not be_running
          expect(service('rsync')).to_not be_enabled
	end

end
