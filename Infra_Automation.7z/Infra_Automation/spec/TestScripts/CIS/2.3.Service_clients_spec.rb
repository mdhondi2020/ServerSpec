require 'spec_helper'

describe 'CIS-REHL6-v2.0.2-2.3 Service Clients' do

	it 'CIS-RHEL7-v2.2.0-2.3.1 Ensure NIS Client is not installed' do
	  expect(package('ypbind')).to_not be_installed
	end

	it 'CIS-RHEL7-v2.2.0-2.3.2 Ensure rsh client is not installed' do
	  expect(package('rsh')).to_not be_installed
	end

	it 'CIS-RHEL7-v2.2.0-2.3.3 Ensure talk client is not installed' do
	  expect(package('talk')).to_not be_installed
	end

	it 'CIS-RHEL7-v2.2.0-2.3.4 Ensure telnet client is not installed' do
	  expect(package('telnet')).to_not be_installed
	end

	it 'CIS-RHEL7-v2.2.0-2.3.5 Ensure LDAP client is not installed' do
	  expect(package('openldap-clients')).to_not be_installed
	end
end