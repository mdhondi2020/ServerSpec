require 'spec_helper'


describe 'CIS-RHEL7-v2.2.0-6.1 System File Permissions' do


	
	
	it 'CIS-RHEL7-v2.2.0-6.1.10 Ensure no world writable files exit' do
	  expect(command('df --local -P | awk {"if (NR!=1) print $6"} | xargs -I "{}" find "{}" -xdev -type f -perm -0002').stdout).to match(//)
	end
	
	it 'CIS-RHEL7-v2.2.0-6.1.11 Ensure no unowned files or directories exist' do
	  expect(command('df --local -P | awk {"if (NR!=1) print $6"} | xargs -I "{}" find "{}" -xdev -nouser').stdout).to match(//)
	end
	
	it 'CIS-RHEL7-v2.2.0-6.1.12 Ensure no ungrouped files or directories exist' do
	  expect(command('df --local -P | awk {"if (NR!=1) print $6"} | xargs -I "{}" find "{}" -xdev -nogroup').stdout).to match(//)
	end
	
	it 'CIS-RHEL7-v2.2.0-6.1.13 Audit SUID Executables' do
	  expect(command('df --local -P | awk {"if (NR!=1) print $6"} | xargs -I "{}" find "{}" -xdev -type f -perm -4000').stdout).to match(//)
	end
	
	it 'CIS-RHEL7-v2.2.0-6.1.14 Audit SGID Executables' do
	  expect(command('df --local -P | awk {"if (NR!=1) print $6"} | xargs -I "{}" find "{}" -xdev -type f -perm -2000').stdout).to match(//)
	end
end