require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-1.2 Configure Software Updates' do 

	it 'CIS-RHEL7-v2.2.0-1.2.1 Ensure package manager repositories are configured' do
	  pending("How to check it")
	  raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-1.2.2 Ensure gpgcheck is globally activated' do
       pending("How to check it")
	  expect(command("grep ^gpgcheck /etc/yum.repos.d/* | awk -F \":\" {' print $2 '} | sort").stdout).to_not contain ('gpgcheck=0')
	end

	it 'CIS-RHEL7-v2.2.0-1.2.3 Ensure GPG keys are configured' do
		expect(command("rpm -q gpg-pubkey --qf '%{name}-%{version}-%{release}'").stdout)
	  raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-1.2.4 Ensure Red Hat Network or Subscription Manager connection is configured' do
	  pending("How to check it")
	  raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-1.2.5 Disable the rhnsd Daemon' do
	  expect(service('rhnsd')).to_not be_enabled
	end

end