require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-3.4 TCP Wrappers' do

	it 'CIS-RHEL7-v2.2.0-3.4.1 Ensure TCP Wrappers is installed' do
	  expect(package('tcp_wrappers')).to be_installed
	end

	it 'CIS-RHEL7-v2.2.0-3.4.2 Ensure /etc/hosts.allow is configured' do
          expect(file('/etc/hosts.allow')).to be_file
	end

	it 'CIS-RHEL7-v2.2.0-3.4.3 Ensure /etc/hosts.deny is configured' do
          expect(file('/etc/hosts.deny')).to be_file
          expect(file('/etc/hosts.deny')).to contain('ALL: ALL')
	end

	it 'CIS-RHEL7-v2.2.0-3.4.4 Ensure permissions on /etc/hosts.allow are configured' do
          expect(file('/etc/hosts.allow')).to be_mode(644)
          expect(command('stat /etc/hosts.allow grep "Access: (" | awk  {\' print $5 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/hosts.allow | grep "Access: (" | awk  {\' print $6 \'}').stdout).to contain ('root')
          expect(command('stat /etc/hosts.allow | grep "Access: (" | awk  {\' print $9 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/hosts.allow | grep "Access: (" | awk  {\' print $10 \'}').stdout).to contain ('root')
	end
    
	it 'CIS-RHEL7-v2.2.0-3.4.5 Ensure permissions on /etc/hosts.deny are configured' do
          expect(file('/etc/hosts.deny')).to be_mode(644)
          expect(command('stat /etc/hosts.deny grep "Access: (" | awk  {\' print $5 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/hosts.deny | grep "Access: (" | awk  {\' print $6 \'}').stdout).to contain ('root')
          expect(command('stat /etc/hosts.deny | grep "Access: (" | awk  {\' print $9 \'}').stdout).to contain ('0/')
          expect(command('stat /etc/hosts.deny | grep "Access: (" | awk  {\' print $10 \'}').stdout).to contain ('root')
	end

end
