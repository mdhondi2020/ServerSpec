require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-3.5 Uncommon Network Protocols' do


	it 'CIS-RHEL7-v2.2.0-3.5.1 Ensure DCCP is disabled' do
	  expect(command('modprobe -n -v dccp').stdout).to match(/install \/bin\/true/)
	  expect(command('lsmod | grep dcc').stdout).to match (//)
	end

	it 'CIS-RHEL7-v2.2.0-3.5.2 Ensure SCTP is disabled' do
	  expect(command('modprobe -n -v sctp').stdout).to match(/install \/bin\/true/)
	  expect(command('lsmod | grep sctp').stdout).to match (//)
	end

	it 'CIS-RHEL7-v2.2.0-3.5.3 Ensure RDS is disabled' do
	  expect(command('modprobe -n -v rds').stdout).to match(/install \/bin\/true/)
	  expect(command('lsmod | grep rds').stdout).to match (//)
	end

	it 'CIS-RHEL7-v2.2.0-3.5.4 Ensure TIPC is disabled' do
	  expect(command('modprobe -n -v tipc').stdout).to match(/install \/bin\/true/)
	  expect(command('lsmod | grep tipc').stdout).to match (//)
	end

end