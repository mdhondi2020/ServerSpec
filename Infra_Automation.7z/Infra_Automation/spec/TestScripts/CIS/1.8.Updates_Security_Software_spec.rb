require 'spec_helper'


describe 'CIS-RHEL7-v2.2.0-1.8 Updates and Security Software' do
	
	it 'CIS-RHEL7-v2.2.0-1.8 Ensure updates, patches, and additional security software are installed' do
	  expect(command('yum check-update --security --quiet | grep -v "^$" | wc -l').stdout).to match(/^0/)
	  
	end

end
