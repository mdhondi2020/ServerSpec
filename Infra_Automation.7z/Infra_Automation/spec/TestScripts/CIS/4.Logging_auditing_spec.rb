
require 'spec_helper'


describe 'CIS-RHEL7-v2.2.0-4 Logging and Auditing' do


	it 'CIS-RHEL7-v2.2.0-4.1.1.1 Ensure audit log storage size is configured' do
	  expect(file('/etc/audit/auditd.conf')).to match(/^max_log_file = \d+/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.1.2 Ensure system is disabled when audit logs are full' do
	  expect(file('/etc/audit/auditd.conf')).to match(/^space_left_action = email/)
	  expect(file('/etc/audit/auditd.conf')).to match(/^action_mail_acct = root/)
 	  expect(file('/etc/audit/auditd.conf')).to match(/^admin_space_left_action = halt/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.1.3 Ensure audit logs are not automatically deleted' do
	  expect(file('/etc/audit/auditd.conf')).to match(/^max_log_file_action = keep_logs/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.2 Ensure auditd service is enabled' do
	  expect(service('auditd')).to be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-4.1.3 Ensure auditing for processes that start prior to auditd is enabled' do
	  expect(command('grep "^\s*kernel" /boot/grub/grub.conf').stdout).to contain('audit=1')
	end

	it 'CIS-RHEL7-v2.2.0-4.1.4 Ensure events that modify date and time information are collected' do
	  expect(command('grep time-change /etc/audit/audit.rules | grep b64 | grep adjtimex').stdout).to match(/-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change/)
	  expect(command('grep time-change /etc/audit/audit.rules | grep b32 | grep adjtimex').stdout).to match(/-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change/)
	  expect(command('grep time-change /etc/audit/audit.rules | grep b64 | grep clock_settime').stdout).to match(/-a always,exit -F arch=b64 -S clock_settime -k time-change/)
	  expect(command('grep time-change /etc/audit/audit.rules | grep b32 | grep clock_settime').stdout).to match(/-a always,exit -F arch=b32 -S clock_settime -k time-change/)
	  expect(command('grep time-change /etc/audit/audit.rules | grep localtime').stdout).to match(/-w \/etc\/localtime -p wa -k time-change/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.5 Ensure events that modify user/group information are collected' do
	  expect(command('grep identity /etc/audit/audit.rules | grep "/etc/group"').stdout).to match(/-w \/etc\/group -p wa -k identity/)
	  expect(command('grep identity /etc/audit/audit.rules | grep "/etc/passwd"').stdout).to match(/-w \/etc\/passwd -p wa -k identity/)
	  expect(command('grep identity /etc/audit/audit.rules | grep "/etc/gshadow"').stdout).to match(/-w \/etc\/gshadow -p wa -k identity/)
	  expect(command('grep identity /etc/audit/audit.rules | grep "/etc/shadow"').stdout).to match(/-w \/etc\/shadow -p wa -k identity/)
	  expect(command('grep identity /etc/audit/audit.rules | grep "/etc/security/opasswd"').stdout).to match(/-w \/etc\/security\/opasswd -p wa -k identity/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.6 Ensure events that modify the system\'s network environment are collected' do
	  expect(command('grep system-locale /etc/audit/audit.rules | grep b64 | grep sethostname').stdout).to match(/-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale/)
	  expect(command('grep system-locale /etc/audit/audit.rules | grep b32 | grep sethostname').stdout).to match(/-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale/)
	  expect(command('grep system-locale /etc/audit/audit.rules | grep "/etc/issue"').stdout).to match(/-w \/etc\/issue -p wa -k system-locale/)
	  expect(command('grep system-locale /etc/audit/audit.rules | grep "/etc/issue.net"').stdout).to match(/-w \/etc\/issue\.net -p wa -k system-locale/)
	  expect(command('grep system-locale /etc/audit/audit.rules | grep "/etc/hosts"').stdout).to match(/-w \/etc\/hosts -p wa -k system-locale/)
	  expect(command('grep system-locale /etc/audit/audit.rules | grep "/etc/sysconfig/network"').stdout).to match(/-w \/etc\/sysconfig\/network -p wa -k system-locale/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.7 Ensure events that modify the system\'s Mandatory Access Controls are collected' do
	  expect(command('grep MAC-policy /etc/audit/audit.rules').stdout).to match(/-w \/etc\/selinux\/ -p wa -k MAC-policy/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.8 Ensure login and logout events are collected' do
	  expect(command('grep logins /etc/audit/audit.rules | grep lastlog').stdout).to match(/-w \/var\/log\/lastlog -p wa -k logins/)
	  expect(command('grep logins /etc/audit/audit.rules | grep faillock').stdout).to match(/-w \/var\/run\/faillock\/ -p wa -k logins/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.9 Ensure session initiation information is collected' do
	  expect(command('grep session /etc/audit/audit.rules | grep utmp').stdout).to match(/-w \/var\/run\/utmp -p wa -k session/)
	  expect(command('grep session /etc/audit/audit.rules | grep wtmp').stdout).to match(/-w \/var\/log\/wtmp -p wa -k session/)
	  expect(command('grep session /etc/audit/audit.rules | grep btmp').stdout).to match(/-w \/var\/log\/btmp -p wa -k session/)
	end
	
	it 'CIS-RHEL7-v2.2.0-4.1.10 Ensure discretionary access control permission modification events are collected' do
	  expect(command('grep perm_mod /etc/audit/audit.rules | grep b64 | grep -v lchown | grep -v removexattr').stdout).to match(/-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=500 -F auid!=4294967295 -k perm_mod/)
	  expect(command('grep perm_mod /etc/audit/audit.rules | grep b32 | grep -v lchown | grep -v removexattr').stdout).to match(/-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=500 -F auid!=4294967295 -k perm_mod/)
	  expect(command('grep perm_mod /etc/audit/audit.rules | grep b64 | grep lchown').stdout).to match(/-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=500 -F auid!=4294967295 -k perm_mod/)
	  expect(command('grep perm_mod /etc/audit/audit.rules | grep b32 | grep lchown').stdout).to match(/-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=500 -F auid!=4294967295 -k perm_mod/)
	  expect(command('grep perm_mod /etc/audit/audit.rules | grep b64 | grep removexattr').stdout).to match(/-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=500 -F auid!=4294967295 -k perm_mod/)
	  expect(command('grep perm_mod /etc/audit/audit.rules | grep b32 | grep removexattr').stdout).to match(/-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=500 -F auid!=4294967295 -k perm_mod/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.11 Ensure unsuccessful unauthorized file access attempts are collected' do
	  expect(command('grep access /etc/audit/audit.rules | grep b64 | grep EACCES').stdout).to match(/-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=500 -F auid!=4294967295 -k access/)
	  expect(command('grep access /etc/audit/audit.rules | grep b32 | grep EACCES').stdout).to match(/-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=500 -F auid!=4294967295 -k access/)
	  expect(command('grep access /etc/audit/audit.rules | grep b64 | grep EPERM').stdout).to match(/-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=500 -F auid!=4294967295 -k access/)
	  expect(command('grep access /etc/audit/audit.rules | grep b32 | grep EPERM').stdout).to match(/-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=500 -F auid!=4294967295 -k access/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.12 Ensure use of privileged commands is collected' do
	  pending("How to check it")
          raise "This is pending"
	end
	
	it 'CIS-RHEL7-v2.2.0-4.1.13 Ensure successful file system mounts are collected' do
	  expect(command('grep mounts /etc/audit/audit.rules | grep b64').stdout).to match(/-a always,exit -F arch=b64 -S mount -F auid>=500 -F auid!=4294967295 -k mounts/)
	  expect(command('grep mounts /etc/audit/audit.rules | grep b32').stdout).to match(/-a always,exit -F arch=b32 -S mount -F auid>=500 -F auid!=4294967295 -k mounts/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.14 Ensure file deletion events by users are collected' do
	  expect(command('grep delete /etc/audit/audit.rules | grep b64').stdout).to match(/-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=500 -F auid!=4294967295 -k delete/)
	  expect(command('grep delete /etc/audit/audit.rules | grep b32').stdout).to match(/-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=500 -F auid!=4294967295 -k delete/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.15 Ensure changes to system administration scope (sudoers) is collected' do
	  expect(command('grep scope /etc/audit/audit.rules | grep "/etc/sudoers"').stdout).to match(/-w \/etc\/sudoers -p wa -k scope/)
	  expect(command('grep scope /etc/audit/audit.rules | grep "/etc/sudoers.d"').stdout).to match(/-w \/etc\/sudoers\.d -p wa -k scope/)
	end


	it 'CIS-RHEL7-v2.2.0-4.1.16 Ensure system administrator actions (sudolog) are collected' do
	  expect(command('grep actions /etc/audit/audit.rules').stdout).to match(/-w \/var\/log\/sudo.log -p wa -k actions/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.17 Ensure kernel module loading and unloading is collected' do
	  expect(command('grep modules /etc/audit/audit.rules | grep "-w /sbin/insmod -p x -k modules"').stdout).to match(/-w \/sbin\/insmod -p x -k modules/)
	  expect(command('grep modules /etc/audit/audit.rules | grep "-w /sbin/rmmod -p x -k modules"').stdout).to match(/-w \/sbin\/rmmod -p x -k modules/)
	  expect(command('grep modules /etc/audit/audit.rules | grep "-w /sbin/modprobe -p x -k modules"').stdout).to match(/-w \/sbin\/modprobe -p x -k modules/)
	  expect(command('grep modules /etc/audit/audit.rules | grep b64').stdout).to match(/-a always,exit arch=b64 -S init_module -S delete_module -k modules/)
	end

	it 'CIS-RHEL7-v2.2.0-4.1.18 Ensure the audit configuration is immutable' do
	  expect(command('grep "^\s*[^#]" /etc/audit/audit.rules | tail -1').stdout).to match(/-e 2/)
	end

	it 'CIS-RHEL7-v2.2.0-4.2.1.1 Ensure rsyslog Service is enabled' do
	  expect(service('rsyslog')).to be_enabled
	end
	
	it 'CIS-RHEL7-v2.2.0-4.2.1.2 Ensure logging is configured' do
	  pending("How to check it")
          raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-4.2.1.3 Ensure rsyslog default file permissions configured' do
	  expect(command('grep ^\$FileCreateMode \/etc\/rsyslog.conf').stdout).to match(/\$FileCreateMode 0640/)
	end

	it 'CIS-RHEL7-v2.2.0-4.2.1.4 Ensure rsyslog is configured to send logs to a remote log host' do
	  expect(command('grep "^\*\.\*[^I][^I]\*@" \/etc\/rsyslog.conf').stdout).to match(/^\s*\*\.\*\s+@/)
	end

	it 'CIS-RHEL7-v2.2.0-4.2.1.5 Ensure remote rsyslog messages are only accepted on designated log hosts' do
	  expect(command('grep \'$ModLoad imtcp.so\' /etc/rsyslog.conf').stdout).to match(/\$ModLoad imtcp.so/)
	  expect(command('grep \'$InputTCPServerRun\' /etc/rsyslog.conf').stdout).to match(/\$InputTCPServerRun 514/)
	end

	it 'CIS-RHEL7-v2.2.0-4.2.2.1 Ensure syslog-ng service is enabled' do
	  expect(service('syslog-ng')).to be_enabled
	end

	it 'CIS-RHEL7-v2.2.0-4.2.2.2 Ensure logging is configured' do
          pending("How to check it")
          raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-4.2.2.3 Ensure syslog-ng default file permissions configured' do
	  expect(command('grep ^options \/etc\/syslog-ng\/syslog-ng\.conf').stdout).to match(/^options\s+\{\s+chain_hostnames\(off\)\;\s+flush_lines\(0\)\;\s+perm\(0640\)\;\s+stats_freq\(3600\)\;\s+threaded\(yes\)\;\s+\}\;/)
	end

	it 'CIS-RHEL7-v2.2.0-4.2.2.4 Ensure syslog-ng is configured to send logs to a remote log host' do
	  pending("How to check it")
          raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-4.2.2.5 Ensure remote syslog-ng messages are only accepted on designated log hosts' do
	  pending("How to check it")
          raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-4.2.3 Ensure rsyslog or syslog-ng is installed' do
	  expect(package('rsyslog')).to be_installed
	end

	it 'CIS-RHEL7-v2.2.0-4.2.4 Ensure permissions on all logfiles are configured' do
          pending("How to check it")
          raise "This is pending"
        end

	it 'CIS-RHEL7-v2.2.0-4.3 Ensure logrotate is configured' do
          pending("How to check it")
          raise "This is pending"
	end
end