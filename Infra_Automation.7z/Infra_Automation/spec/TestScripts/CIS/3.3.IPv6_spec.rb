require 'spec_helper'

describe 'CIS-RHEL7-v2.2.0-3.3 IPv6' do 

	

	it 'CIS-RHEL7-v2.2.0-3.3.3 Ensure IPv6 is disabled' do
	  expect(command('modprobe -c | grep ipv6 | grep ^options').stdout).to contain ('options ipv6 disable=1')
	end

end