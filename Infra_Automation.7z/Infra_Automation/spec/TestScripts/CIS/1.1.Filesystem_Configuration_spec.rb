require 'spec_helper'
require 'serverspec'


describe 'CIS-RHEL7-v2.2.0-1.1 Filesystem Configuration' do

	
	it 'CIS-RHEL7-v2.2.0-1.1.1.1 Ensure mounting of cramfs filesystems is disabled' do
	  expect(kernel_module('cramfs')).to_not be_loaded
        end

	it 'CIS-RHEL7-v2.2.0-1.1.1.2 Ensure mounting of freevxfs filesystems is disabled' do
	  expect(kernel_module('freexvs')).to_not be_loaded
        end

	it 'CIS-RHEL7-v2.2.0-1.1.1.3 Ensure mounting of jffs2 filesystems is disabled' do
	  expect(kernel_module('jffs2')).to_not be_loaded
        end

	it 'CIS-RHEL7-v2.2.0-1.1.1.4 Ensure mounting of hfs filesystems is disabled' do
	  expect(kernel_module('hfs')).to_not be_loaded
        end

	it 'CIS-RHEL7-v2.2.0-1.1.1.5 Ensure mounting of hfsplus filesystems is disabled' do
	  expect(kernel_module('hfsplus')).to_not be_loaded
        end

	it 'CIS-RHEL7-v2.2.0-1.1.1.6 Ensure mounting of squashfs filesystems is disabled' do
	  expect(kernel_module('squashfs')).to_not be_loaded
        end

	it 'CIS-RHEL7-v2.2.0-1.1.1.7 Ensure mounting of udf filesystems is disabled' do
	  expect(kernel_module('squashfs')).to_not be_loaded
        end

	it 'CIS-RHEL7-v2.2.0-1.1.1.8 Ensure mounting of FAT filesystems is disabled' do
	  expect(kernel_module('vfat')).to_not be_loaded
        end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.2 Ensure separate partition exists for /tmp' do
          expect(file('/tmp')).to be_mounted
	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.3 Ensure nodev option set on /tmp partition' do
          expect(file('/tmp')).to be_mounted.with(options: { nodev: true })
	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.4 Ensure nosuid option on /tmp partition' do
          expect(file('/tmp')).to be_mounted.with(options: { nosuid: true })
 	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.5 Ensure noexec option set on /tmp partition' do
          expect(file('/tmp')).to be_mounted.with(options: { noexec: true })
 	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.6 Ensure separate partition exists for /var' do
          expect(file('/var')).to be_mounted
	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.7 Ensure separate partition exists for /var/tmp' do
          expect(file('/var/tmp')).to be_mounted
 	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.8 Ensure nodev option set on /var/tmp partition' do
          expect(file('/var/tmp')).to be_mounted.with(options: { nodev: true })
	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.9 Ensure nosuid option on /var/tmp partition' do
          expect(file('/var/tmp')).to be_mounted.with(options: { nosuid: true })
 	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.10 Ensure noexec option set on /var/tmp partition' do
          expect(file('/var/tmp')).to be_mounted.with(options: { noexec: true })
 	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.11 Ensure separate partition exists for /var/log' do
          expect(file('/var/log')).to be_mounted
 	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.12 Ensure separate partition exists for /var/log/audit' do
          expect(file('/var/log/audit')).to be_mounted
 	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
	it 'CIS-RHEL7-v2.2.0-1.1.13 Ensure separate partition exits for /home' do
          expect(file('/home')).to be_mounted
  	end

# The following filesystem is not a separate partition as we are using the Azure Marketplace image which doesn't create a separate partition
  	it 'CIS-RHEL7-v2.2.0-1.1.14 Ensure nodev option set on /home partition' do
          expect(file('/home')).to be_mounted.with(options: { nodev: true })
 	end

 	it 'CIS-RHEL7-v2.2.0-1.1.15 Ensure nodev option set on /dev/shm partition' do
          expect(file('/dev/shm')).to be_mounted.with(options: { nodev: true })
  	end

	it 'CIS-RHEL7-v2.2.0-1.1.16 Ensure nosuid option set on /dev/shm partition' do
          expect(file('/dev/shm')).to be_mounted.with(options: { nosuid: true })
	end

	it 'CIS-RHEL7-v2.2.0-1.1.17 Ensure noexec option set on /dev/shm partition' do
          expect(file('/dev/shm')).to be_mounted.with(options: { noexec: true })
	end

	it 'CIS-RHEL7-v2.2.0-1.1.18 Ensure nodev option set on removable media partitions' do
	  pending("Assume which removable media are present")
	  raise "This is pending"
	end

	it 'CIS-RHEL7-v2.2.0-1.1.19 Ensure nosuid option set on removable media partitions' do
          pending("Assume which removable media are present")
	  raise "This is pending"
        end

	it 'CIS-RHEL7-v2.2.0-1.1.20 Ensure noexec option set on removable media partitions' do
          pending("Assume which removable media are present")
	  raise "This is pending"
        end

	it 'CIS-RHEL7-v2.2.0-1.1.21 Ensure sticky bit is set on all world-writable directories' do
	  expect(command("df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d\( -perm -0002 -a ! -perm -1000 \) 2>/dev/null").stdout).to match(//)
	end

	it 'CIS-RHEL7-v2.2.0-1.1.22 Disable Automounting' do
	  expect(service('autofs')).to_not be_enabled
	end

end